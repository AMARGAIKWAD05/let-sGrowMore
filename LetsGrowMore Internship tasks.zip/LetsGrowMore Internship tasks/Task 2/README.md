# LGM-Task-2
Hello #connections  
I'm glad to share that I have completed the Intermediate Level Task #task2 as a Web Development Intern at #letsgrowmorecommunity VIP Nov.  
Intermediate Level Task:  Task 2: Create a web application using create-react-app. 
Github link: https://github.com/rohitkhedkar2709/LGM-Task-2  
Thank you Aman Kesarwani sir and #letsgrowmorecommunity for this great opportunity.  

#intern #webdevelopment #react #opportunity
